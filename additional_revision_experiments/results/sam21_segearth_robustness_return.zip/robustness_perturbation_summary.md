# Robustness to Observation-Condition Perturbations

- Dataset: held-out `datasets/2024-seg` test subset (32 fixed images).
- Models: six models with valid fine-tuned checkpoints; no model was retrained.
- Metrics: global two-class mIoU, vegetation F1, and pixel accuracy calculated by this script on the same original-resolution ground-truth masks.
- Deltas: perturbed metric minus the clean metric for the same model; values are proportions, not percentage points.
- Shadow/illumination: deterministic synthetic cast shadows, seeded by filename and therefore identical for every model.

## Clean baseline and robustness summary

| Model | Clean mIoU | Clean F1 | Clean Accuracy | Mean Delta_mIoU | Worst Delta_mIoU | Worst perturbation |
|---|---:|---:|---:|---:|---:|---|
| SAM2.1-Tiny | 0.7624 | 0.9040 | 0.8757 | -0.0026 | -0.0207 | gaussian_blur, kernel_7 |

## Perturbation-category summary

| Perturbation category | Mean Delta_mIoU |
|---|---:|
| gaussian_blur | -0.0150 |
| brightness | +0.0003 |
| contrast | +0.0003 |
| shadow_illumination | +0.0021 |

## Paper-table suggestion

Use the clean-baseline robustness table as the compact manuscript table. If space allows, add the perturbation-category summary as a second short table.

Suggested paragraph:

> To examine adaptation to observation-condition changes, we conducted an inference-only robustness test using the same fixed 32-image held-out subset from the 2024 segmentation dataset. Brightness, contrast, Gaussian blur, and synthetic shadow/illumination perturbations were applied identically to all completed models, while ground-truth masks were unchanged. Among the completed models, SAM2.1-Tiny showed the smallest average mIoU degradation under perturbations (mean Delta_mIoU = -0.0026). The most challenging condition overall was gaussian_blur (mean Delta_mIoU = -0.0150).

## Revision response draft

> Response to Reviewer 2, Comment 4: Thank you for the helpful suggestion. We added a lightweight inference-only robustness analysis to evaluate adaptation to common observation-condition variations. Using the same fixed held-out subset, we applied brightness, contrast, Gaussian blur, and synthetic shadow/illumination perturbations to the input images and evaluated all completed models with the same pixel-level mIoU, F1, and accuracy implementation. The results show that SAM2.1-Tiny is comparatively stable across perturbations, whereas gaussian_blur is the most damaging observation change on average. We report these results in the robustness summary table and provide the experimental scripts and CSV outputs for reproducibility.

## Per-condition results

| Model | Perturbation | Strength | mIoU | F1 | Accuracy | Delta_mIoU | Delta_F1 | Delta_Accuracy |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| SAM2.1-Tiny | clean | none | 0.7624 | 0.9040 | 0.8757 | +0.0000 | +0.0000 | +0.0000 |
| SAM2.1-Tiny | brightness | 0.70 | 0.7659 | 0.9053 | 0.8776 | +0.0035 | +0.0013 | +0.0019 |
| SAM2.1-Tiny | brightness | 0.85 | 0.7653 | 0.9051 | 0.8772 | +0.0028 | +0.0010 | +0.0015 |
| SAM2.1-Tiny | brightness | 1.15 | 0.7606 | 0.9036 | 0.8748 | -0.0018 | -0.0005 | -0.0009 |
| SAM2.1-Tiny | brightness | 1.30 | 0.7590 | 0.9032 | 0.8740 | -0.0034 | -0.0008 | -0.0016 |
| SAM2.1-Tiny | contrast | 0.75 | 0.7647 | 0.9048 | 0.8769 | +0.0023 | +0.0008 | +0.0012 |
| SAM2.1-Tiny | contrast | 0.90 | 0.7638 | 0.9045 | 0.8764 | +0.0013 | +0.0004 | +0.0007 |
| SAM2.1-Tiny | contrast | 1.10 | 0.7618 | 0.9039 | 0.8754 | -0.0006 | -0.0001 | -0.0003 |
| SAM2.1-Tiny | contrast | 1.25 | 0.7608 | 0.9037 | 0.8749 | -0.0016 | -0.0004 | -0.0008 |
| SAM2.1-Tiny | gaussian_blur | kernel_3 | 0.7531 | 0.9004 | 0.8704 | -0.0093 | -0.0037 | -0.0052 |
| SAM2.1-Tiny | gaussian_blur | kernel_5 | 0.7473 | 0.8976 | 0.8669 | -0.0151 | -0.0064 | -0.0088 |
| SAM2.1-Tiny | gaussian_blur | kernel_7 | 0.7417 | 0.8943 | 0.8631 | -0.0207 | -0.0098 | -0.0126 |
| SAM2.1-Tiny | shadow_illumination | mild | 0.7640 | 0.9046 | 0.8765 | +0.0016 | +0.0005 | +0.0008 |
| SAM2.1-Tiny | shadow_illumination | moderate | 0.7646 | 0.9048 | 0.8768 | +0.0022 | +0.0007 | +0.0011 |
| SAM2.1-Tiny | shadow_illumination | strong | 0.7648 | 0.9048 | 0.8769 | +0.0024 | +0.0007 | +0.0012 |

## Robustness ranking

Higher mean Delta_mIoU (i.e., a smaller average loss from the clean condition) indicates stronger robustness.

| Rank | Model | Mean Delta_mIoU over all 14 perturbation settings |
|---:|---|---:|
| 1 | SAM2.1-Tiny | -0.0026 |

## Perturbation sensitivity

More negative mean Delta_mIoU indicates a more damaging perturbation category, averaged over tested strengths and completed models.

| Perturbation | Mean Delta_mIoU |
|---|---:|
| gaussian_blur | -0.0150 |
| brightness | +0.0003 |
| contrast | +0.0003 |
| shadow_illumination | +0.0021 |

## Models not completed

- `SegEarth-OV` was not completed: ImportError: cannot import name 'find_pruneable_heads_and_indices' from 'transformers.modeling_utils' (/usr/local/lib/python3.12/dist-packages/transformers/modeling_utils.py)
